export interface Table {
  make(): void
}
