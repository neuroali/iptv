declare module 'markdown-include'
